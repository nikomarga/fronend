//variables
let nameTeacher;
let hoursWork;
let years ;
let fortnightValue;
let categoria;
let  valorHourPh  = 90000;
let valorHourMagister = 70000 ;
let valorHourEspecialista = 50000;
let valorHourProfesional = 20000;
let especialidad;
let bonus;
let valorNeto;
let teacherMagister = 0;
let teacherPh = 0;
let teacherEspecialista = 0;
let teacherProfesional = 0;
let totalProfesinales;
let fortnightHours;
let totalNominaPh = 0 ;
let totalNominaMagister = 0 ;
let totalNominaEspecialista  = 0;
let totalNominaProfesional = 0;
let totalNominaProfesionales = 0;
let i = 1;
let respuesta;


//entradas 

do {
    
nameTeacher = prompt("Digite el nombre del docente: ");
hoursWork = prompt("Digite las horas diarias de trabajo: ");
years = prompt("Cuantos años tiene en la empresa?  ");
categoria = parseInt(prompt("Categoria del docente: \n1.Ph \n2.Magister \n3.Especialista \n4.Profesional"));

    switch (categoria) {
        case 1:
            especialidad = "Ph";
            categoria = valorHourPh;
            teacherPh ++;
            break;
        case 2:
            especialidad = "Magister";
            categoria = valorHourMagister;
            teacherMagister ++;
        break;
        case 3:
            especialidad = "Especialista";
            categoria = valorHourEspecialista;
            teacherEspecialista ++;
        break;
        case 4:
            especialidad = "Profesional";
            categoria = valorHourProfesional;
            teacherProfesional ++;
        break
    }
    //calculos
   
    fortnightHours = hoursWork * 15;
    fortnightValue = (categoria * hoursWork) * 15;

    if (years < 2) {
        bonus = fortnightValue * 0.30;
    }else if(years >= 2 && years <= 5){
        bonus = fortnightValue * 0.50;
    }else if(years > 5 && years <= 10){
        bonus = fortnightValue * 0.60;
    }else if(years > 10){
        bonus = fortnightValue * 0.90;
    }else{
        bonus = 0;
    }

    valorNeto = fortnightValue + bonus;
    

    // acumulador de nomina
    if (especialidad === "Ph") {
        totalNominaPh += valorNeto;
    } else if (especialidad === "Magister") {
        totalNominaMagister += valorNeto;
    } else if (especialidad === "Especialista") {
        totalNominaEspecialista += valorNeto;
    } else if (especialidad === "Profesional") {
        totalNominaProfesional += valorNeto;
    }
    //salidas por profesor
    document.write("<hr>");
    document.write(" NOMINA DOCENTE " +i);
    document.write("<hr>");
    document.write(`<p>Nombre docente: ${nameTeacher}</p>`);
    document.write(`<p>Categoria: ${especialidad}</p>`);
    document.write(`<p>Horas trabajadas en 15 dias: ${fortnightHours}</p>`);
    document.write(`<p>Valor de hora: $${categoria}</p>`);
    document.write(`<p>bonificacion: $${bonus}</p>`);
    document.write(`<p>Neto a pagar: $${valorNeto}</p>`);
    i ++;

    

    respuesta = parseInt(prompt("Desea agregar a otro docente: \n1.SI \n2.NO"));
} while (respuesta === 1); 

totalProfesinales = teacherPh + teacherMagister + teacherEspecialista + teacherProfesional; 
totalNominaProfesionales = totalNominaPh + totalNominaMagister + totalNominaEspecialista + totalNominaProfesional;

//salidas totales
document.write("<hr>");
document.write("<h3>Total, profesores</h3>");
document.write("<hr>");
document.write(`<p>Total docentes : ${totalProfesinales}</p>`);
document.write(`<p>Cantidad de personas PH: ${teacherPh}</p>`);
document.write(`<p>Cantidad de personas Magister: ${teacherMagister}</p>`);
document.write(`<p>Cantidad de personas Especialistas: ${teacherEspecialista}</p>`);
document.write(`<p>Cantidad de personas Profecionales: ${teacherProfesional}</p>`);

document.write("<hr>");
document.write("<h2>NOMINA PROFESORES</h2>");
document.write(`<p>Suma nomina de PH $${totalNominaPh}</p>`);
document.write(`<p>Suma nomina de Magister $${totalNominaMagister}</p>`);
document.write(`<p>Suma nomina Especialistas $${totalNominaEspecialista}</p>`);
document.write(`<p>Suma nomina Profesionales $${totalNominaProfesional}</p>`);
document.write(`<h3>Total de nominas : $${totalNominaProfesionales}</h3>`);